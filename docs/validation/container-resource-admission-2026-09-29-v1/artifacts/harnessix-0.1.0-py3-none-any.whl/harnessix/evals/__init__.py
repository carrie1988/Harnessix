"""Coding Eval公共契约；平台执行入口按需导入，不污染合同读取链路。"""

from importlib import import_module
from typing import TYPE_CHECKING

from harnessix.evals.campaign import (
    CompletedCodingEvalTrial,
    build_coding_eval_campaign_report,
)
from harnessix.evals.campaign_contracts import (
    CodingEvalCampaignPlan,
    CodingEvalCampaignReport,
    CodingEvalCampaignSummary,
    CodingEvalCampaignTrial,
)
from harnessix.evals.campaign_execution_contracts import (
    CodingEvalCampaignExecutionState,
    CodingEvalCampaignRunConfig,
    CodingEvalCampaignRunReport,
)
from harnessix.evals.catalog import (
    HistoricalCodingEval,
    historical_coding_eval,
    historical_coding_eval_ids,
    historical_coding_eval_versions,
)
from harnessix.evals.checks import (
    historical_check_arguments,
    historical_python_launcher,
    run_historical_checks,
)
from harnessix.evals.compaction import grade_compaction_semantics
from harnessix.evals.compaction_contracts import (
    COMPACTION_SEMANTIC_CATEGORIES,
    CompactionSemanticCheck,
    CompactionSemanticEvalCase,
    CompactionSemanticEvalReport,
    CompactionSemanticExpectation,
)
from harnessix.evals.contracts import (
    CODING_EVAL_GRADER_VERSION,
    CODING_EVAL_MATERIALIZER_VERSION,
    CODING_EVAL_SPEC_VERSION,
    CodingEvalEnvironment,
    CodingEvalMaterialization,
    CodingEvalReport,
    CodingEvalRunState,
    CodingEvalTask,
    EvalFinalAnswer,
    EvalFinalAnswerEvidence,
    EvalFinalTest,
    EvalGitEvidence,
    EvalTestObservation,
)
from harnessix.evals.delivery_contracts import (
    CHANGE_PACKAGE_SPEC_VERSION,
    DELIVERY_PLAN_SPEC_VERSION,
    DELIVERY_RECORD_SPEC_VERSION,
    CodingEvalChangeImage,
    CodingEvalChangePackage,
    CodingEvalDeliveryPlan,
    CodingEvalDeliveryRecord,
    CodingEvalDeliveryTransition,
)
from harnessix.evals.git_evidence import collect_git_evidence
from harnessix.evals.grader import grade_coding_eval
from harnessix.evals.materializer import (
    MaterializedCodingEval,
    load_materialized_coding_eval,
    materialize_historical_coding_eval,
)
from harnessix.evals.provider_suite_contracts import (
    CodingEvalProviderSuiteEvidenceManifest,
    CodingEvalProviderSuiteRunConfig,
    CodingEvalProviderSuiteRunReport,
)
from harnessix.evals.provider_suite_evidence import (
    build_provider_suite_evidence_manifest,
    publish_provider_suite_evidence,
)
from harnessix.evals.report import (
    read_eval_campaign_execution_state,
    read_eval_campaign_plan,
    read_eval_campaign_report,
    read_eval_report,
    read_eval_suite_case_report,
    read_eval_suite_execution_state,
    read_eval_suite_plan,
    read_eval_suite_report,
    write_eval_campaign_execution_state,
    write_eval_campaign_plan,
    write_eval_campaign_report,
    write_eval_report,
    write_eval_suite_case_report,
    write_eval_suite_execution_state,
    write_eval_suite_plan,
    write_eval_suite_report,
)
from harnessix.evals.run_state import read_eval_run_state, write_eval_run_state
from harnessix.evals.suite import (
    CompletedCodingEvalSuiteCase,
    build_coding_eval_suite_case_report,
    build_coding_eval_suite_report,
    build_coding_eval_suite_report_from_cases,
    build_transcript_evidence,
)
from harnessix.evals.suite_contracts import (
    EVAL_TASK_KINDS,
    CodingEvalRate,
    CodingEvalSuiteCasePlan,
    CodingEvalSuiteCaseReport,
    CodingEvalSuitePlan,
    CodingEvalSuiteReport,
    CodingEvalSuiteSummary,
    CodingEvalTranscriptEvidence,
    CodingEvalTrialTestEvidence,
)
from harnessix.evals.suite_execution_contracts import (
    CodingEvalSuiteCaseRunResult,
    CodingEvalSuiteExecutionState,
    CodingEvalSuiteRunConfig,
    CodingEvalSuiteRunReport,
)
from harnessix.evals.task_pack import (
    LoadedCodingEvalTaskPack,
    build_task_pack_product_profile,
    builtin_coding_eval_task_pack,
    builtin_coding_eval_task_pack_ids,
    builtin_coding_eval_task_pack_versions,
)
from harnessix.evals.task_pack_contracts import (
    CodingEvalReviewFinding,
    CodingEvalReviewOracle,
    CodingEvalTaskPack,
    CodingEvalTaskPackCase,
    CodingEvalTaskPackLicense,
    CodingEvalTaskPackMaterialization,
    CodingEvalTaskPackProfile,
    CodingEvalTaskPackRepository,
    build_coding_eval_review_oracle,
    build_coding_eval_task_pack,
    build_coding_eval_task_pack_profile,
)
from harnessix.evals.task_pack_materializer import (
    MaterializedCodingEvalTaskPackCase,
    load_materialized_task_pack_case,
    materialize_task_pack_case,
)
from harnessix.evals.task_pack_suite import (
    build_task_pack_offline_suite_config,
    build_task_pack_suite_config,
)

if TYPE_CHECKING:
    from harnessix.evals.campaign_execution import run_coding_eval_campaign
    from harnessix.evals.delivery import (
        CodingEvalDeliveryStore,
        build_coding_eval_change_package,
        read_coding_eval_change_package,
        write_coding_eval_change_package,
    )
    from harnessix.evals.provider_suite_execution import run_task_pack_provider_suite
    from harnessix.evals.runner import HistoricalCodingEvalResult, run_historical_coding_eval
    from harnessix.evals.suite_execution import run_coding_eval_suite


__all__ = [
    "CODING_EVAL_GRADER_VERSION",
    "CODING_EVAL_MATERIALIZER_VERSION",
    "CODING_EVAL_SPEC_VERSION",
    "COMPACTION_SEMANTIC_CATEGORIES",
    "CHANGE_PACKAGE_SPEC_VERSION",
    "DELIVERY_PLAN_SPEC_VERSION",
    "DELIVERY_RECORD_SPEC_VERSION",
    "CodingEvalChangeImage",
    "CodingEvalChangePackage",
    "CodingEvalCampaignPlan",
    "CodingEvalCampaignReport",
    "CodingEvalCampaignExecutionState",
    "CodingEvalCampaignRunConfig",
    "CodingEvalCampaignRunReport",
    "CodingEvalCampaignSummary",
    "CodingEvalCampaignTrial",
    "CodingEvalEnvironment",
    "CodingEvalDeliveryPlan",
    "CodingEvalDeliveryRecord",
    "CodingEvalDeliveryStore",
    "CodingEvalDeliveryTransition",
    "CodingEvalMaterialization",
    "CodingEvalProviderSuiteEvidenceManifest",
    "CodingEvalProviderSuiteRunConfig",
    "CodingEvalProviderSuiteRunReport",
    "CodingEvalReport",
    "CodingEvalRunState",
    "CodingEvalRate",
    "CodingEvalSuiteCasePlan",
    "CodingEvalSuiteCaseReport",
    "CodingEvalSuiteCaseRunResult",
    "CodingEvalSuiteExecutionState",
    "CodingEvalSuitePlan",
    "CodingEvalSuiteReport",
    "CodingEvalSuiteRunConfig",
    "CodingEvalSuiteRunReport",
    "CodingEvalSuiteSummary",
    "CodingEvalTask",
    "CodingEvalTaskPack",
    "CodingEvalTaskPackCase",
    "CodingEvalTaskPackLicense",
    "CodingEvalTaskPackMaterialization",
    "CodingEvalTaskPackProfile",
    "CodingEvalTaskPackRepository",
    "CodingEvalTranscriptEvidence",
    "CodingEvalTrialTestEvidence",
    "CodingEvalReviewFinding",
    "CodingEvalReviewOracle",
    "CompactionSemanticCheck",
    "CompactionSemanticEvalCase",
    "CompactionSemanticEvalReport",
    "CompactionSemanticExpectation",
    "CompletedCodingEvalTrial",
    "CompletedCodingEvalSuiteCase",
    "EVAL_TASK_KINDS",
    "EvalFinalAnswer",
    "EvalFinalAnswerEvidence",
    "EvalFinalTest",
    "EvalGitEvidence",
    "EvalTestObservation",
    "HistoricalCodingEval",
    "HistoricalCodingEvalResult",
    "MaterializedCodingEval",
    "MaterializedCodingEvalTaskPackCase",
    "LoadedCodingEvalTaskPack",
    "collect_git_evidence",
    "build_coding_eval_campaign_report",
    "build_coding_eval_suite_case_report",
    "build_coding_eval_review_oracle",
    "build_coding_eval_suite_report",
    "build_coding_eval_suite_report_from_cases",
    "build_coding_eval_task_pack",
    "build_coding_eval_task_pack_profile",
    "build_transcript_evidence",
    "build_task_pack_product_profile",
    "build_task_pack_offline_suite_config",
    "build_task_pack_suite_config",
    "build_provider_suite_evidence_manifest",
    "builtin_coding_eval_task_pack",
    "builtin_coding_eval_task_pack_ids",
    "builtin_coding_eval_task_pack_versions",
    "build_coding_eval_change_package",
    "grade_coding_eval",
    "grade_compaction_semantics",
    "historical_check_arguments",
    "historical_python_launcher",
    "historical_coding_eval",
    "historical_coding_eval_ids",
    "historical_coding_eval_versions",
    "load_materialized_coding_eval",
    "load_materialized_task_pack_case",
    "materialize_historical_coding_eval",
    "materialize_task_pack_case",
    "read_eval_report",
    "read_eval_suite_plan",
    "read_eval_suite_case_report",
    "read_eval_suite_execution_state",
    "read_eval_suite_report",
    "read_eval_campaign_plan",
    "read_eval_campaign_report",
    "read_eval_campaign_execution_state",
    "read_eval_run_state",
    "read_coding_eval_change_package",
    "publish_provider_suite_evidence",
    "run_historical_checks",
    "run_historical_coding_eval",
    "run_coding_eval_campaign",
    "run_coding_eval_suite",
    "run_task_pack_provider_suite",
    "write_eval_report",
    "write_eval_suite_plan",
    "write_eval_suite_case_report",
    "write_eval_suite_execution_state",
    "write_eval_suite_report",
    "write_eval_campaign_plan",
    "write_eval_campaign_report",
    "write_eval_campaign_execution_state",
    "write_eval_run_state",
    "write_coding_eval_change_package",
]


# 仅延迟实际执行依赖，其他合同/纯数据入口保持原导出；不提供Windows执行替身。
_LAZY_EXECUTION_EXPORTS = {
    "run_coding_eval_campaign": "harnessix.evals.campaign_execution",
    "CodingEvalDeliveryStore": "harnessix.evals.delivery",
    "build_coding_eval_change_package": "harnessix.evals.delivery",
    "read_coding_eval_change_package": "harnessix.evals.delivery",
    "write_coding_eval_change_package": "harnessix.evals.delivery",
    "run_task_pack_provider_suite": "harnessix.evals.provider_suite_execution",
    "HistoricalCodingEvalResult": "harnessix.evals.runner",
    "run_historical_coding_eval": "harnessix.evals.runner",
    "run_coding_eval_suite": "harnessix.evals.suite_execution",
}


def __getattr__(name: str) -> object:
    """首次访问执行导出时加载原实现并缓存；合同导入不触发平台专用依赖。"""

    module_name = _LAZY_EXECUTION_EXPORTS.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """列出完整公共导出名，但不为名称发现加载平台执行模块。"""

    return sorted(set(globals()) | set(__all__))
