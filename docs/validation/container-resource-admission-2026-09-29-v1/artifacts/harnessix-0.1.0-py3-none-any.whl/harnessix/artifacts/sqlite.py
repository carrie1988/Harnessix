"""事务Artifact存储：以SQLite事务实现对应持久化端口。"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Callable
from datetime import timedelta
from uuid import UUID

import aiosqlite

from harnessix.agent.approvals import approval_for, request_fingerprint
from harnessix.agent.errors import KernelError
from harnessix.agent.execution import ToolExecutionScope
from harnessix.agent.ids import new_id
from harnessix.agent.models import (
    ApprovalRequestContent,
    EventDraft,
    ItemFinished,
    ItemStarted,
    ItemStatus,
    Thread,
    ToolCallContent,
    ToolResultContent,
)
from harnessix.agent.publication import PublicOutputProtection
from harnessix.agent.reducer import get_turn
from harnessix.artifacts.action_output_store import (
    ActionOutputArtifactMixin,
    validate_action_output_body,
)
from harnessix.artifacts.contracts import (
    MAX_ARTIFACT_BYTES,
    MAX_ARTIFACT_RECORDS,
    MAX_PAGE_BYTES,
    ArtifactOmittedField,
    ArtifactPage,
    ArtifactPolicy,
    ArtifactRef,
    ArtifactToolResult,
    CollectionReport,
    HistoryArtifactPurpose,
    ReadArtifactInput,
    artifact_store_contract,
)
from harnessix.artifacts.persistence import ARTIFACT_READ_SELECT, insert_artifact
from harnessix.artifacts.publication import ArtifactPublicationGuard
from harnessix.domain.models import ApprovalOutcome, EffectClass, utc_now
from harnessix.processes.output_artifact import parse_process_output_document
from harnessix.session.sqlite import SQLiteSessionStore

_HISTORY_ARTIFACT_PURPOSES: frozenset[str] = frozenset(
    {
        "tool_result",
        "batch_effect",
        "process_output",
        "action_review",
        "action_output",
        "artifact_page",
    }
)


def _reject_constant(value: str) -> None:
    raise ValueError("JSON 不允许非有限数字")


def records(body: bytes) -> list[str]:
    if type(body) is not bytes or len(body) > MAX_ARTIFACT_BYTES:
        raise KernelError("artifact_invalid", "Artifact 正文类型或大小不符合契约")
    try:
        text = body.decode("utf-8")
        if text and not text.endswith("\n"):
            raise ValueError("记录未终止")
        lines = text.split("\n")[:-1] if text else []
        if len(lines) > MAX_ARTIFACT_RECORDS:
            raise ValueError("记录过多")
        for line in lines:
            if len(line.encode()) + 1 > MAX_PAGE_BYTES:
                raise ValueError("记录超过页上限")
            json.loads(line, parse_constant=_reject_constant)
        return lines
    except (ValueError, RecursionError):
        raise KernelError("artifact_invalid", "Artifact 不是受支持的有界 UTF-8 JSONL") from None


def _validate_process_output_body(
    row: aiosqlite.Row,
    thread: Thread,
    ref: ArtifactRef,
    body: bytes,
) -> None:
    """核对Process归档正文与Session中已提交的公共流摘要。"""

    try:
        document = parse_process_output_document(body)
        turn = get_turn(thread, UUID(row["turn_id"]))
        result = next(
            item.content
            for item in turn.items
            if isinstance(item.content, ToolResultContent)
            and item.status == ItemStatus.COMPLETED
            and str(item.content.call_id) == row["call_id"]
            and item.content.process is not None
        )
        if not isinstance(result.output, dict):
            raise ValueError("结果类型不匹配")
        for name in ("stdout", "stderr"):
            public = result.output[name]
            stream = getattr(document.summary, name)
            if not isinstance(public, dict) or public != {
                "captured_bytes": stream.captured_bytes,
                "observed_bytes": stream.observed_bytes,
                "observed_sha256": stream.observed_sha256,
                "truncated": stream.truncated,
                "eof": stream.eof,
            }:
                raise ValueError("流摘要不匹配")
        if document.summary.complete != ref.complete:
            raise ValueError("完整性不匹配")
    except (KeyError, StopIteration, ValueError):
        raise KernelError("artifact_corrupt", "Process Artifact正文与结果不一致") from None


class SQLiteArtifactStore(ActionOutputArtifactMixin):
    """同一 Session 数据库内发布；正文不通过外部文件进行双写。"""

    def __init__(
        self,
        session: SQLiteSessionStore,
        *,
        policy: ArtifactPolicy | None = None,
        fault: Callable[[str], None] | None = None,
        public_output_protection: PublicOutputProtection | None = None,
    ) -> None:
        self._session = session
        self._policy = policy or ArtifactPolicy()
        self._fault = fault or (lambda _: None)
        self._publication = ArtifactPublicationGuard(public_output_protection, session._publication)

    @property
    def session(self) -> SQLiteSessionStore:
        return self._session

    @property
    def policy(self) -> ArtifactPolicy:
        return self._policy

    def contract(self) -> dict[str, object]:
        return artifact_store_contract(self.policy)

    async def publish(
        self,
        thread_id: UUID,
        turn_id: UUID,
        call: ToolCallContent,
        output: ArtifactToolResult,
        *,
        expected_sequence: int,
        max_output_chars: int,
    ) -> Thread:
        if output.publisher is not self:
            raise KernelError("artifact_store_mismatch", "Artifact 载荷绑定了不同的发布器")
        owner = self.session._runtime_owner_token
        if owner is None:
            raise KernelError("artifact_runtime_required", "Artifact 发布需要活跃的 Session 宿主")
        lines = records(output.body)
        result = ToolResultContent.model_validate_json(output.result.model_dump_json())
        if (
            result.outcome != "succeeded"
            or result.call_id != call.call_id
            or call.effect_class != EffectClass.READ_ONLY
            or not isinstance(output.workspace_scope, str)
            or not re.fullmatch(r"[0-9a-f]{64}", output.workspace_scope)
            or type(output.complete) is not bool
        ):
            raise KernelError("artifact_invalid", "Artifact 与只读调用结果不匹配")
        now = utc_now()
        ref = ArtifactRef(
            artifact_id=new_id(),
            sha256=hashlib.sha256(output.body).hexdigest(),
            size_bytes=len(output.body),
            records=len(lines),
            complete=output.complete,
            expires_at=now + timedelta(seconds=self.policy.ttl_seconds),
        )
        published = result.model_copy(
            update={"output": {"preview": result.output, "artifact": ref.model_dump(mode="json")}}
        )
        if len(published.model_dump_json()) > max_output_chars:
            raise KernelError("tool_output_too_large", "Artifact 引用与预览超过 Kernel 上限")
        item_id = new_id()
        batch = self.session._freeze_batch(
            (
                EventDraft(
                    turn_id=turn_id, payload=ItemStarted(item_id=item_id, content=published)
                ),
                EventDraft(
                    turn_id=turn_id,
                    payload=ItemFinished(
                        item_id=item_id, content=published, status=ItemStatus.COMPLETED
                    ),
                ),
            )
        )
        async with self.session._connection() as database:
            await database.execute("BEGIN IMMEDIATE")
            thread = await self.session._snapshot(database, thread_id)
            if thread is None or thread.sequence != expected_sequence:
                raise KernelError("sequence_conflict", "Artifact 发布时会话已变化")
            ToolExecutionScope.for_pending_call(thread, turn_id, call)
            turn = get_turn(thread, turn_id)
            if call.requires_approval:
                item = approval_for(turn, call)
                if (
                    item is None
                    or item.status != ItemStatus.COMPLETED
                    or not isinstance(item.content, ApprovalRequestContent)
                    or item.content.decision is None
                    or item.content.decision.outcome != ApprovalOutcome.APPROVED
                    or item.content.request_fingerprint != request_fingerprint(thread, turn, call)
                ):
                    raise KernelError("approval_mismatch", "Artifact 发布缺少匹配的批准")
            await self._check_quota(database, thread_id, turn_id, ref.size_bytes)
            await insert_artifact(
                database,
                ref,
                thread_id=thread_id,
                turn_id=turn_id,
                call_id=call.call_id,
                workspace_scope=output.workspace_scope,
                body=output.body,
                purpose="tool_result",
                created_at=now,
                publication=self._publication,
            )
            self._fault("artifact.after_insert")
            updated, _ = await self.session._append_in_transaction(
                database, thread_id, batch, expected_sequence=expected_sequence
            )
            self._fault("artifact.before_commit")
            if self.session._runtime_owner_token is not owner:
                raise KernelError("artifact_runtime_required", "Artifact 发布期间宿主已关闭")
            await database.commit()
            self._fault("artifact.after_commit")
            return updated

    async def publish_action_review(
        self,
        thread_id: UUID,
        turn_id: UUID,
        call: ToolCallContent,
        body: bytes,
        *,
        artifact_id: UUID,
        workspace_scope: str,
        expected_sequence: int,
    ) -> ArtifactRef:
        """查询优先发布审批Review；孤儿正文不可读，重放必须复用同一收据。"""

        from harnessix.artifacts.action_review_store import publish_action_review

        lines = records(body)
        return await publish_action_review(
            self.session,
            self.policy,
            self._fault,
            self._check_quota,
            thread_id,
            turn_id,
            call,
            body,
            artifact_id=artifact_id,
            workspace_scope=workspace_scope,
            expected_sequence=expected_sequence,
            record_count=len(lines),
            publication=self._publication,
        )

    async def _check_quota(
        self, database: aiosqlite.Connection, thread_id: UUID, turn_id: UUID, size: int
    ) -> None:
        cursor = await database.execute(
            "SELECT COUNT(*), COALESCE(SUM(length(body)), 0), "
            "COALESCE(SUM(CASE WHEN thread_id = ? AND turn_id = ? THEN size_bytes ELSE 0 END), 0), "
            "COALESCE(SUM(CASE WHEN thread_id = ? AND turn_id = ? THEN 1 ELSE 0 END), 0) "
            "FROM agent_artifacts",
            (str(thread_id), str(turn_id), str(thread_id), str(turn_id)),
        )
        row = await cursor.fetchone()
        assert row is not None
        if (
            row[0] >= self.policy.max_manifests
            or row[1] + size > self.policy.max_live_bytes
            or row[2] + size > self.policy.max_turn_bytes
            or row[3] >= self.policy.max_turn_count
        ):
            raise KernelError("artifact_quota_exceeded", "Artifact 配额不足，未发布正文或结果")

    @staticmethod
    def _body(row: aiosqlite.Row, thread: Thread, ref: ArtifactRef) -> list[str]:
        body = row["body"]
        if (
            row["state"] != "published"
            or ref.expires_at <= utc_now()
            or not isinstance(body, bytes)
        ):
            if row["state"] == "expired" or ref.expires_at <= utc_now():
                raise KernelError("artifact_expired", "Artifact 已过期")
            raise KernelError("artifact_corrupt", "Artifact状态或正文不存在")
        if len(body) != ref.size_bytes or hashlib.sha256(body).hexdigest() != ref.sha256:
            raise KernelError("artifact_corrupt", "Artifact 正文校验失败")
        try:
            lines = records(body)
        except KernelError:
            raise KernelError("artifact_corrupt", "Artifact 记录损坏") from None
        if len(lines) != ref.records:
            raise KernelError("artifact_corrupt", "Artifact 记录数不一致")
        if row["purpose"] == "process_output":
            _validate_process_output_body(row, thread, ref, body)
        if row["purpose"] == "action_output":
            validate_action_output_body(row, thread, ref, body)
        return lines

    @staticmethod
    def _reference(row: aiosqlite.Row, thread: Thread) -> ArtifactRef:
        from harnessix.artifacts.reference import validate_artifact_reference

        return validate_artifact_reference(row, thread)

    async def read(
        self,
        thread_id: UUID,
        workspace_scope: str,
        artifact_id: UUID,
        *,
        offset: int = 0,
        limit: int = 100,
    ) -> ArtifactPage:
        if (
            type(offset) is not int
            or type(limit) is not int
            or not 0 <= offset <= MAX_ARTIFACT_RECORDS
            or not 1 <= limit <= 200
        ):
            raise KernelError("artifact_invalid_cursor", "Artifact 分页参数不合法")
        async with self.session._connection() as database:
            await database.execute("BEGIN")
            cursor = await database.execute(
                ARTIFACT_READ_SELECT + " WHERE artifact_id = ? "
                "AND thread_id = ? AND workspace_scope = ?",
                (str(artifact_id), str(thread_id), workspace_scope),
            )
            row = await cursor.fetchone()
            if row is None:
                raise KernelError("artifact_not_found", "Artifact 不存在或不属于当前作用域")
            thread = await self.session._snapshot(database, thread_id)
            if thread is None:
                raise KernelError("artifact_corrupt", "Artifact 归属不存在")
            self._publication.require_proof(row)
            try:
                ref = self._reference(row, thread)
            except KernelError as error:
                if error.code == "artifact_unreferenced":
                    raise KernelError(
                        "artifact_not_found", "Artifact不存在或不属于当前作用域"
                    ) from None
                raise
            lines = self._body(row, thread, ref)
            await self._publication.check_body(row["body"], purpose=row["purpose"])
        if offset > len(lines):
            raise KernelError("artifact_invalid_cursor", "Artifact 偏移超过记录范围")
        selected, size = [], 0
        for line in lines[offset : offset + limit]:
            encoded = len(line.encode()) + 1
            if size + encoded > MAX_PAGE_BYTES:
                break
            selected.append(line + "\n")
            size += encoded
        end = offset + len(selected)
        return ArtifactPage(
            artifact=ref,
            offset=offset,
            text="".join(selected),
            next_offset=end if end < len(lines) else None,
        )

    async def verify_reference(
        self,
        thread_id: UUID,
        call_id: UUID,
        reference: ArtifactRef,
        *,
        workspace_scope: str,
        purpose: HistoryArtifactPurpose,
        omitted_field: ArtifactOmittedField | None = None,
    ) -> None:
        if purpose not in _HISTORY_ARTIFACT_PURPOSES:
            raise KernelError("artifact_invalid", "Artifact用途不符合契约")
        async with self.session._connection() as database:
            await database.execute("BEGIN")
            cursor = await database.execute(
                ARTIFACT_READ_SELECT + " WHERE artifact_id = ? AND thread_id = ? "
                "AND workspace_scope = ?",
                (str(reference.artifact_id), str(thread_id), workspace_scope),
            )
            row = await cursor.fetchone()
            if row is None:
                raise KernelError("artifact_not_found", "Artifact不存在或不属于当前作用域")
            if purpose != "artifact_page" and (
                row["call_id"] != str(call_id) or row["purpose"] != purpose
            ):
                raise KernelError("artifact_not_found", "Artifact不存在或不属于当前作用域")
            thread = await self.session._snapshot(database, thread_id)
            if thread is None:
                raise KernelError("artifact_corrupt", "Artifact归属不存在")
            self._publication.require_proof(row)
            try:
                stored = self._reference(row, thread)
            except KernelError as error:
                if error.code == "artifact_unreferenced":
                    raise KernelError(
                        "artifact_not_found", "Artifact不存在或不属于当前作用域"
                    ) from None
                raise
            if stored != reference:
                raise KernelError("artifact_corrupt", "Artifact引用与已提交manifest不一致")
            lines = self._body(row, thread, stored)
            await self._publication.check_body(row["body"], purpose=row["purpose"])
            if purpose == "artifact_page":
                self._verify_page(thread, call_id, stored, lines)
            if omitted_field is not None:
                if purpose != "tool_result" or not stored.complete:
                    raise KernelError("artifact_corrupt", "局部Artifact不能证明结果省略")
                self._verify_coverage(thread, call_id, lines, omitted_field)

    @staticmethod
    def _verify_page(thread: Thread, call_id: UUID, ref: ArtifactRef, lines: list[str]) -> None:
        calls = [
            i.content
            for t in thread.turns
            for i in t.items
            if isinstance(i.content, ToolCallContent) and i.content.call_id == call_id
        ]
        results = [
            i.content
            for t in thread.turns
            for i in t.items
            if isinstance(i.content, ToolResultContent)
            and i.content.call_id == call_id
            and i.status == ItemStatus.COMPLETED
        ]
        try:
            if len(calls) != 1 or len(results) != 1 or calls[0].tool != "read_artifact":
                raise ValueError("分页调用缺失")
            args = ReadArtifactInput.model_validate_json(json.dumps(calls[0].arguments))
            if args.artifact_id != ref.artifact_id or results[0].outcome != "succeeded":
                raise ValueError("分页引用错绑")
            page = ArtifactPage.model_validate_json(json.dumps(results[0].output, allow_nan=False))
            selected: list[str] = []
            size = 0
            for line in lines[args.offset : args.offset + args.limit]:
                size += len(line.encode()) + 1
                if size > MAX_PAGE_BYTES:
                    break
                selected.append(line + "\n")
            end = args.offset + len(selected)
            if (
                page.artifact != ref
                or page.offset != args.offset
                or args.offset > len(lines)
                or page.text != "".join(selected)
                or page.next_offset != (end if end < len(lines) else None)
            ):
                raise ValueError("分页正文不匹配")
        except (ValueError, TypeError):
            raise KernelError("artifact_corrupt", "Artifact分页结果与完整正文不一致") from None

    @staticmethod
    def _verify_coverage(
        thread: Thread, call_id: UUID, lines: list[str], field: ArtifactOmittedField
    ) -> None:
        result = next(
            i.content
            for t in thread.turns
            for i in t.items
            if isinstance(i.content, ToolResultContent)
            and i.content.call_id == call_id
            and i.status == ItemStatus.COMPLETED
        )
        assert isinstance(result.output, dict)
        preview = result.output.get("preview")
        values = [json.loads(line) for line in lines]
        if field != "preview":
            preview = preview.get(field) if isinstance(preview, dict) else None

        # JSON类型必须一致；Python的True == 1不能证明归档覆盖。
        def canonical(value: object) -> str:
            return json.dumps(
                value, ensure_ascii=False, sort_keys=True, allow_nan=False, separators=(",", ":")
            )

        covered = (
            isinstance(preview, list)
            and len(preview) <= len(values)
            and canonical(preview) == canonical(values[: len(preview)])
        ) or (
            field == "preview" and len(values) == 1 and canonical(preview) == canonical(values[0])
        )
        if not covered:
            raise KernelError("artifact_corrupt", "Artifact正文未覆盖被省略的结果字段")

    async def collect(self, *, limit: int = 100, after: UUID | None = None) -> CollectionReport:
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise KernelError("artifact_invalid_cursor", "清理批次大小不合法")
        now = utc_now()
        expired = protected = 0
        async with self.session._connection() as database:
            await database.execute("BEGIN IMMEDIATE")
            cursor = await database.execute(
                ARTIFACT_READ_SELECT + " WHERE state = 'published' AND expires_at <= ? "
                "AND artifact_id > ? ORDER BY artifact_id LIMIT ?",
                (now.isoformat(), str(after) if after else "", limit),
            )
            rows = list(await cursor.fetchall())
            for row in rows:
                thread = await self.session._snapshot(database, UUID(row["thread_id"]))
                if thread is None:
                    raise KernelError("artifact_corrupt", "Artifact 归属不存在")
                try:
                    self._reference(row, thread)
                except KernelError as error:
                    if error.code != "artifact_unreferenced":
                        raise
                if thread.active_turn_id is not None:
                    protected += 1
                    continue
                await database.execute(
                    "UPDATE agent_artifacts SET state = 'expired', body = NULL "
                    "WHERE artifact_id = ?",
                    (row["artifact_id"],),
                )
                expired += 1
            self._fault("artifact.before_collect_commit")
            await database.commit()
        return CollectionReport(
            len(rows),
            expired,
            protected,
            now,
            UUID(rows[-1]["artifact_id"]) if len(rows) == limit else None,
        )
