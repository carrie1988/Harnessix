import unittest

from src.mathbox import add


class AddTests(unittest.TestCase):
    def test_adds_positive_integers(self) -> None:
        self.assertEqual(add(2, 3), 5)


if __name__ == "__main__":
    unittest.main()
