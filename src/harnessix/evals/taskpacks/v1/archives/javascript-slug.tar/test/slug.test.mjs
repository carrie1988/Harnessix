import assert from "node:assert/strict";
import test from "node:test";

import { slugify } from "../src/slug.mjs";

test("slugify converts words to lowercase slugs", () => {
  assert.equal(slugify("Harnessix Code"), "harnessix-code");
});
