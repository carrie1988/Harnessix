export function slugify(value) {
  return value.trim().replace(/\s+/g, "-");
}
